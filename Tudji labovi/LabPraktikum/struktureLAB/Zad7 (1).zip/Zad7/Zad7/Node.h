#pragma once
#include <iostream>
using namespace std;

class StaticSortDList {
public:
	int dim;
	int LRMP;//ukazuje na prvi slobodan element
	int head;//ukazuje na prvi element
	int *prev;
	int *next;
	int *info;
	StaticSortDList(int maxNo);
	void AddToHead(int);
	~StaticSortDList();
	void BSort();
	void print();
};
