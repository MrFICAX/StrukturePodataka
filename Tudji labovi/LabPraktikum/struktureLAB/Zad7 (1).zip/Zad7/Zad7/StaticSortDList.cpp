#include "Node.h"

StaticSortDList::StaticSortDList(int maxNo)
{
	dim = maxNo;
	info = new int[dim];
	next = new int[dim];
	prev = new int[dim];
	LRMP = 0; head = -1;
	for (int i = 0; i<dim; i++)
	{
		prev[i] = i - 1;
		info[i] = 0;
		if (i == dim - 1)
		{
			next[i] = -1;
		}
		else
		{
			next[i] = i + 1;
		}
	}
}

StaticSortDList::~StaticSortDList(){
	delete[] next;
	delete[] prev;
	delete[] info;
}

void StaticSortDList::AddToHead(int novi) {
	if (LRMP == -1)
		return;
	if(head==-1)
	{ 
		int tmp = LRMP;
		info[tmp] = novi;
		LRMP = next[tmp];
		prev[tmp] = -1;
		next[tmp] = -1;
		head = tmp;
	}
	else
	{
		int tmp = LRMP;
		info[tmp] = novi;
		LRMP = next[tmp];
		next[tmp] = head;
		prev[tmp] = -1;
		prev[head] = tmp;
		head = tmp;
	}
}

void StaticSortDList::print()
{
	int tmp;
	for (tmp = head; tmp != -1; tmp = next[tmp])
	{
		cout <<info[tmp]<<" ";
	}
	/*cout << "\t " << info[tmp];
	cout << endl;*/
}

void StaticSortDList::BSort()
{
	if (head == -1)
		return;
	int i, j, n = 0;
	int p, t;
	for (int q = head; q != -1; q = next[q])
		n++;//broji koliko ima

	for (i = 1, t = head; i<n; t = next[t], i++)
		for (j = 0, p = head; j<n - i; p = next[p], j++)
			if (info[p] > info[next[p]])
			{
				int temp = info[p];
				info[p] = info[next[p]];
				info[next[p]] = temp;
			}
}