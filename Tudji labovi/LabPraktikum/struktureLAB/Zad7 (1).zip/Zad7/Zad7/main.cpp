#include "Node.h"

void main()
{
	StaticSortDList lista(5);
	lista.AddToHead(8);
	lista.AddToHead(3);
	lista.AddToHead(2);
	lista.AddToHead(6);
	lista.print();
	lista.BSort();
	lista.print();


}